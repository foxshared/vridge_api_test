﻿namespace VRE.Vridge.API.Client.Messages.v3.Discovery
{
    public enum BeaconOrigin
    {
        Server,
        Client
    }
}
