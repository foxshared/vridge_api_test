﻿namespace VRE.Vridge.API.Client.Messages.BasicTypes
{
    public enum HandType : byte
    {
        Left,
        Right
    }
}
