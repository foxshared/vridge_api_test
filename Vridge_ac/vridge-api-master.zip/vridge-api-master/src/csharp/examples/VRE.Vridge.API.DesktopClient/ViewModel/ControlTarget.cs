﻿namespace VRE.Vridge.API.DesktopTester.ViewModel
{
    public enum ControlTarget
    {
        Head = 0, 
        Controller1 = 1,
        Controller2 = 2,
        Controller3 = 3,
        Controller4 = 4,
    }
}
