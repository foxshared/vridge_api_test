package com.riftcat.vridge.api.client.java.codes;

public class TrackedDeviceStatus {
    public static final byte Active = 0;
    public static final byte TempUnavailable = 1;
    public static final byte Disabled = 2;
}
