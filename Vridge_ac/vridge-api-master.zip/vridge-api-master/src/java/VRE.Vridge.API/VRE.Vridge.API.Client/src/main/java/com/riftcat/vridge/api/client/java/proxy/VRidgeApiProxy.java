package com.riftcat.vridge.api.client.java.proxy;

public interface VRidgeApiProxy {
    void disconnect();
}
