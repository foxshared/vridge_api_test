package com.riftcat.vridge.api.client.java.control;

public class ControlRequestCode {

    public static int RequestEndpoint = 1;
    public static int RequestStatus = 2;

}
