package com.riftcat.vridge.api.client.java.utils;

public interface ILog {
    void debug(String s);
    void error(String s);
}
