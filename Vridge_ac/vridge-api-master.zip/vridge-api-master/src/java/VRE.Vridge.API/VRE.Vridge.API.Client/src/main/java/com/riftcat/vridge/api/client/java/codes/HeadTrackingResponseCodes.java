package com.riftcat.vridge.api.client.java.codes;

public class HeadTrackingResponseCodes {

    public static int AcceptedYourData = 0;

    public static int SendingCurrentTrackedPose = 2;

    public static int PhoneDataTimeout = 253;
    public static int BadRequest = 254;
    public static int Disconnecting = 255;

}
