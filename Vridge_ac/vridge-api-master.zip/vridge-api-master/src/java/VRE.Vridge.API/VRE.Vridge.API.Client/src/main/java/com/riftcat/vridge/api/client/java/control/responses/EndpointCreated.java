package com.riftcat.vridge.api.client.java.control.responses;

public class EndpointCreated extends  ControlResponseHeader {
    public int TimeoutSec;
    public int Port;
}
