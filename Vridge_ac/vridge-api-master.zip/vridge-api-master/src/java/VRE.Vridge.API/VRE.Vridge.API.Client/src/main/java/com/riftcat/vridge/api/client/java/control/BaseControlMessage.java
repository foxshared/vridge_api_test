package com.riftcat.vridge.api.client.java.control;

public class BaseControlMessage {

    public int ProtocolVersion = 3;
    public int Code;

}
