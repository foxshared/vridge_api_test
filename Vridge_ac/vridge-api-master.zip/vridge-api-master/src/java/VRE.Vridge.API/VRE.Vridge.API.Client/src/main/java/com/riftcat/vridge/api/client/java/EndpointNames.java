package com.riftcat.vridge.api.client.java;

public class EndpointNames {
    public static final String HeadTracking = "HeadTracking";
    public static final String Controller   = "Controller";
    public static final String Broadcast    = "Broadcast";
}
