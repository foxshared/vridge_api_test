package com.riftcat.vridge.api.client.java.codes;

public class ControllerStateRequestCodes {
    public static int Disconnect = 255;
    public static int SendFullState = 1;
    public static int RecenterHead = 2;

    public static int Origin_Zero = 0;

}
